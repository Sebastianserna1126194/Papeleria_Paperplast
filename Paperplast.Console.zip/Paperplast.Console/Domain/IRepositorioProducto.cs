﻿using System.Collections.Generic;

namespace Paperplast.Domain
{
    public interface IRepositorioProducto
    {
        void Agregar(Producto p);
        Producto? ObtenerPorCodigo(string codigo);
        IEnumerable<Producto> Listar();
        void Eliminar(string codigo);
    }
}
