﻿using System.Collections.Generic;
using System.Linq;
using Paperplast.Domain;

namespace Paperplast.Infrastructure
{
    public class RepositorioEnMemoria : IRepositorioProducto
    {
        private readonly Dictionary<string, Producto> _db = new();

        public void Agregar(Producto p) => _db[p.Codigo] = p;

        public Producto? ObtenerPorCodigo(string codigo) =>
            _db.TryGetValue(codigo, out var p) ? p : null;

        public IEnumerable<Producto> Listar() => _db.Values.ToList();

        public void Eliminar(string codigo) => _db.Remove(codigo);
    }
}
