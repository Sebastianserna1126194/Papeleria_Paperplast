﻿using System;
using System.Collections.Generic;
using System.Linq;
using Paperplast.Domain;

namespace Paperplast.App
{
    public class ServicioInventario : IServicioInventario
    {
        private readonly IRepositorioProducto _repo;

        public ServicioInventario(IRepositorioProducto repo)
        {
            _repo = repo;
        }

        public void CrearProducto(string codigo, string nombre, decimal precio, int cantidad = 0, string desc = "")
        {
            if (_repo.ObtenerPorCodigo(codigo) != null)
                throw new InvalidOperationException("Producto ya existe");

            var p = new Producto(codigo, nombre, precio, cantidad, desc);
            _repo.Agregar(p);
        }

        public void Vender(string codigo, int cantidad)
        {
            var p = _repo.ObtenerPorCodigo(codigo)
                ?? throw new InvalidOperationException("Producto no existe");

            p.AjustarCantidad(-cantidad);
            _repo.Agregar(p); // actualiza en el repositorio
        }

        public IEnumerable<Producto> Buscar(string texto)
        {
            texto = texto?.ToLower() ?? string.Empty;
            return _repo.Listar().Where(p =>
                p.Codigo.ToLower().Contains(texto) ||
                p.Nombre.ToLower().Contains(texto));
        }

        public IEnumerable<Producto> StockBajo(int umbral) =>
            _repo.Listar().Where(p => p.Cantidad <= umbral);

        public void AjustarStock(string codigo, int nueva)
        {
            var p = _repo.ObtenerPorCodigo(codigo)
                ?? throw new InvalidOperationException("No existe");
            p.SetCantidad(nueva);
            _repo.Agregar(p);
        }

        public IEnumerable<Producto> Listar() => _repo.Listar();
    }
}

public interface IServicioInventario
{
    void CrearProducto(string codigo, string nombre, decimal precio, int cantidad = 0, string desc = "");
    void Vender(string codigo, int cantidad);
    IEnumerable<Paperplast.Domain.Producto> Buscar(string texto);
    IEnumerable<Paperplast.Domain.Producto> StockBajo(int umbral);
    void AjustarStock(string codigo, int nueva);
    IEnumerable<Paperplast.Domain.Producto> Listar();
}
