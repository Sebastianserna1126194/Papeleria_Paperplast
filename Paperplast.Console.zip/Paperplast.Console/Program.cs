﻿using System;
using Paperplast.Domain;
using Paperplast.Infrastructure;
using Paperplast.App;

class Program
{
    static void Main()
    {
        // Usa RepositorioEnMemoria() si no quieres guardar en archivo
        var repo = new RepositorioJson("inventario.json");
        var servicio = new ServicioInventario(repo);

        while (true)
        {
            Console.WriteLine("\n--- Paperplast - Inventario ---");
            Console.WriteLine("1) Crear producto  2) Vender  3) Ajustar stock  4) Buscar  5) Listar  6) Stock bajo  0) Salir");
            Console.Write("Opción: ");
            var op = Console.ReadLine();
            if (op == "0") break;

            try
            {
                if (op == "1")
                {
                    Console.Write("Código: "); var codigo = Console.ReadLine()!;
                    Console.Write("Nombre: "); var nombre = Console.ReadLine()!;
                    Console.Write("Precio: "); var precio = decimal.Parse(Console.ReadLine()!);
                    Console.Write("Cantidad inicial: "); var cant = int.Parse(Console.ReadLine()!);
                    servicio.CrearProducto(codigo, nombre, precio, cant);
                    Console.WriteLine("Producto creado.");
                }
                else if (op == "2")
                {
                    Console.Write("Código: "); var codigo = Console.ReadLine()!;
                    Console.Write("Cantidad vendida: "); var cant = int.Parse(Console.ReadLine()!);
                    servicio.Vender(codigo, cant);
                    Console.WriteLine("Venta registrada.");
                }
                else if (op == "3")
                {
                    Console.Write("Código: "); var codigo = Console.ReadLine()!;
                    Console.Write("Nueva cantidad: "); var nueva = int.Parse(Console.ReadLine()!);
                    servicio.AjustarStock(codigo, nueva);
                    Console.WriteLine("Stock ajustado.");
                }
                else if (op == "4")
                {
                    Console.Write("Texto a buscar: "); var txt = Console.ReadLine()!;
                    var res = servicio.Buscar(txt);
                    foreach (var p in res) Console.WriteLine(p);
                }
                else if (op == "5")
                {
                    foreach (var p in servicio.Listar()) Console.WriteLine(p);
                }
                else if (op == "6")
                {
                    Console.Write("Umbral: "); var u = int.Parse(Console.ReadLine()!);
                    foreach (var p in servicio.StockBajo(u)) Console.WriteLine(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
