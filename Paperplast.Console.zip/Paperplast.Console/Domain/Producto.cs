﻿using System;

namespace Paperplast.Domain
{
    public class Producto
    {
        public string Codigo { get; }
        public string Nombre { get; private set; }
        public string Descripcion { get; private set; }
        public decimal Precio { get; private set; }
        private int _cantidad;
        public int Cantidad => _cantidad;

        public Producto(string codigo, string nombre, decimal precio, int cantidad = 0, string descripcion = "")
        {
            if (string.IsNullOrWhiteSpace(codigo)) throw new ArgumentException("Código requerido");
            if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentException("Nombre requerido");
            if (precio < 0) throw new ArgumentException("Precio inválido");

            Codigo = codigo;
            Nombre = nombre;
            Precio = precio;
            _cantidad = Math.Max(0, cantidad);
            Descripcion = descripcion;
        }

        public void AjustarCantidad(int delta)
        {
            if (_cantidad + delta < 0) throw new InvalidOperationException("No hay stock suficiente");
            _cantidad += delta;
        }

        public void SetCantidad(int nueva)
        {
            if (nueva < 0) throw new ArgumentException("Cantidad no puede ser negativa");
            _cantidad = nueva;
        }

        public override string ToString() =>
            $"[{Codigo}] {Nombre} - Cant: {_cantidad} - Precio: {Precio:C}";
    }
}
