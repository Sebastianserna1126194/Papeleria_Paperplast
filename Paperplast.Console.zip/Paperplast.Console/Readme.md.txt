Inventario en Consola Paperplast 
Autor: Sebastián  
Materia: Taller POO con C# en .NET 8  
Nivel: Principiante–intermedio  

//Descripción

Aplicación de consola que permite gestionar el inventario de la papelería (Paperplast Barbosa): 

--Encapsulamiento: Los objetos controlan su estado así como Producto valida la cantidad 
- Abstracción: Interfaces IRepositorioProducto, IServicioInventario definen contratos 
- Herencia: Producto base puede tener derivados como ProductoConsumibl
- Polimorfismo: Repositorios en memoria o en JSON que implementan la misma interfaz 


//Usuarios
- Administrador: crea productos, ajusta inventario, exporta/importa
- Cajero/Operador: registra ventas, consulta stock
- Auditor: revisa reportes de stock


// Funcionalidades principales
- CRUD de productos (crear, listar, actualizar, eliminar)  
- Registrar ventas con control de stock  
- Ajustar inventario manualmente 
- Buscar productos por código o nombre  
- Reporte de productos con stock bajo 
- Persistencia en archivo inventario.json  


//Estructura del proyecto

Domain/
	Producto.cs
	IRepositorioProducto.cs
App/
	ServicioInventario.cs
	IServicioInventario.cs
Infrastructura/
	RepositorioEnMemoria.cs
	RepositorioJson.cs
Program.cs
Paperplast.Console.csproj



---

// Cómo ejecutar

Requisitos:

- Tener instalado .NET v8

Verifica instalación con el código en cmd:

dotnet --versión



Ejecutar el código:

cd Paperplast.Console
dotnet run

Verás las diferentes opciones como: 1) Crear producto o 5) Listar, que sirve para dar la lista de productos creados 

Si deseas salir, indicas la opción 0)
