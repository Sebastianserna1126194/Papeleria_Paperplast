﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Paperplast.Domain;

namespace Paperplast.Infrastructure
{
    public class RepositorioJson : IRepositorioProducto
    {
        private readonly string _ruta;
        private readonly Dictionary<string, Producto> _db = new();

        public RepositorioJson(string ruta)
        {
            _ruta = ruta;
            if (File.Exists(_ruta))
            {
                var txt = File.ReadAllText(_ruta);
                try
                {
                    var lista = JsonSerializer.Deserialize<List<ProductoDto>>(txt);
                    if (lista != null)
                    {
                        foreach (var d in lista)
                            _db[d.Codigo] = d.ToProducto();
                    }
                }
                catch { /* si falla, deja base vacía */ }
            }
        }

        public void Agregar(Producto p)
        {
            _db[p.Codigo] = p;
            Guardar();
        }

        public Producto? ObtenerPorCodigo(string codigo) =>
            _db.TryGetValue(codigo, out var p) ? p : null;

        public IEnumerable<Producto> Listar() => _db.Values.ToList();

        public void Eliminar(string codigo)
        {
            _db.Remove(codigo);
            Guardar();
        }

        private void Guardar()
        {
            var lista = _db.Values.Select(ProductoDto.FromProducto).ToList();
            var txt = JsonSerializer.Serialize(lista, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_ruta, txt);
        }

        private record ProductoDto(string Codigo, string Nombre, string Descripcion, decimal Precio, int Cantidad)
        {
            public Producto ToProducto() =>
                new Producto(Codigo, Nombre, Precio, Cantidad, Descripcion);

            public static ProductoDto FromProducto(Producto p) =>
                new ProductoDto(p.Codigo, p.Nombre, p.Descripcion, p.Precio, p.Cantidad);
        }
    }
}
